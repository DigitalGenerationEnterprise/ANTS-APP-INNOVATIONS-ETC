#!/usr/bin/env bash
# One-command staged launcher for the Christopher AI-PC bundle.

set -Eeuo pipefail
IFS=$'\n\t'
umask 077

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF="$BASE_DIR/RUN-ME-FIRST.sh"
WORKSTATION="$BASE_DIR/CHRISTOPHER-FRESH-KUBUNTU.sh"
AUTOPILOT="$BASE_DIR/CHRISTOPHER-OPENCLAW-AUTOPILOT.sh"
INTELLIGENCE="$BASE_DIR/INTELLIGENCE.sh"
GUI_MAX="$BASE_DIR/CHRISTOPHER-GUI-MAX.sh"
AI_ROOT="${AI_ROOT:-$HOME/AI-PC}"
STATE_DIR="$HOME/.local/state/christopher-ai-pc-bootstrap"
AUTOSTART_DIR="$HOME/.config/autostart"
AUTOSTART_FILE="$AUTOSTART_DIR/christopher-finish-setup.desktop"
LOG_FILE="$STATE_DIR/bootstrap.log"

say() { printf '%s\n' "$*"; }
info() { printf 'INFO: %s\n' "$*"; }
warn() { printf 'WARNING: %s\n' "$*" >&2; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

usage() {
  cat <<'EOF'
Christopher AI-PC staged setup

Run as your normal Kubuntu desktop user:
  ./RUN-ME-FIRST.sh

The launcher safely resumes completed stages after a reboot. It may ask you to
complete OpenClaw, Codex and GitHub browser authentication.
EOF
}

pause_on_error() {
  local code=$?
  warn "Setup stopped with exit code $code."
  warn "Log: $LOG_FILE"
  warn "Fix the displayed problem, then run RUN-ME-FIRST.sh again. Completed stages will be skipped."
  if [[ -t 0 ]]; then
    read -r -p "Press Enter to close..." _ || true
  fi
  exit "$code"
}
trap pause_on_error ERR

ask_yes() {
  local prompt="$1" answer
  if [[ ! -t 0 ]]; then
    return 1
  fi
  read -r -p "$prompt [Y/n] " answer
  [[ -z "$answer" || "$answer" =~ ^[Yy] ]]
}

preflight() {
  [[ "$EUID" -ne 0 ]] || die "Run this as your normal Kubuntu desktop user, not with sudo."
  for file in "$WORKSTATION" "$AUTOPILOT" "$INTELLIGENCE" "$GUI_MAX"; do
    [[ -f "$file" ]] || die "Missing bundle file: $file"
  done
  mkdir -p "$STATE_DIR"
  touch "$LOG_FILE"
  chmod 0700 "$STATE_DIR"
  chmod 0755 "$SELF" "$WORKSTATION" "$AUTOPILOT" "$INTELLIGENCE" "$GUI_MAX"

  exec 9>"$STATE_DIR/bootstrap.lock"
  if have flock; then
    flock -n 9 || die "Another Christopher setup window is already running."
  fi

  if ! sudo -n true 2>/dev/null; then
    say "Kubuntu will ask for your normal sudo password once."
    sudo -v
  fi
}

install_autostart_resume() {
  mkdir -p "$AUTOSTART_DIR"
  cat >"$AUTOSTART_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=Finish Christopher AI-PC Setup
Comment=Continue the staged AI workstation setup after reboot
Exec=konsole -e bash "$SELF" --continue
Terminal=false
X-KDE-autostart-after=panel
X-KDE-StartupNotify=false
EOF
  chmod 0755 "$AUTOSTART_FILE"
}

stage_workstation() {
  local complete="$AI_ROOT/.installer-state/complete"
  local pending="$AI_ROOT/.installer-state/nvidia-resume-pending"
  local waited=0

  if [[ -f "$complete" ]]; then
    info "Stage 1 already complete: Kubuntu/NVIDIA/AI workstation."
    touch "$STATE_DIR/01-workstation.complete"
    return 0
  fi

  say
  say "============================================================"
  say "STAGE 1 — KUBUNTU, NVIDIA AND CORE AI TOOLS"
  say "============================================================"
  say
  install_autostart_resume

  if systemctl is-active --quiet christopher-ai-resume.service 2>/dev/null; then
    say "The post-reboot NVIDIA installer is already continuing in the background."
    say "Waiting for it rather than launching a second installer..."
    while systemctl is-active --quiet christopher-ai-resume.service 2>/dev/null; do
      if (( waited >= 3600 )); then
        die "The resume service has run for one hour. Inspect: sudo journalctl -u christopher-ai-resume.service"
      fi
      sleep 5
      waited=$((waited + 5))
    done
    if [[ -f "$complete" ]]; then
      touch "$STATE_DIR/01-workstation.complete"
      return 0
    fi
    warn "The resume service stopped without its completion marker; rerunning it interactively for a clear error."
  fi

  "$WORKSTATION"

  if [[ -e "$pending" || ! -f "$complete" ]]; then
    say
    say "Stage 1 has paused for its NVIDIA reboot or continuation."
    say "After login, a terminal should reopen automatically."
    say "If it does not, run RUN-ME-FIRST.sh again."
    exit 0
  fi
  touch "$STATE_DIR/01-workstation.complete"
}

stage_autopilot() {
  if [[ -f "$STATE_DIR/02-autopilot.complete" ]] && \
     [[ -x "$AI_ROOT/christopher/bin/christopher" ]]; then
    info "Stage 2 already complete: Christopher Autopilot."
    return 0
  fi

  say
  say "============================================================"
  say "STAGE 2 — OPENCLAW AND CHRISTOPHER AUTOPILOT"
  say "============================================================"
  say
  "$AUTOPILOT" install --install-missing

  if have openclaw && \
     { ! openclaw config validate >/dev/null 2>&1 || \
       ! openclaw gateway status >/dev/null 2>&1; }; then
    say
    say "OpenClaw onboarding will now open. Complete its questions and service setup."
    openclaw onboard --install-daemon
  fi

  if have openclaw; then
    openclaw config validate || die "OpenClaw is still not configured. Rerun this launcher after onboarding."
    "$AUTOPILOT" install
  else
    die "OpenClaw was not installed. Check the log, then rerun."
  fi
  touch "$STATE_DIR/02-autopilot.complete"
}

stage_intelligence() {
  if [[ -f "$STATE_DIR/03-intelligence.complete" ]] && have intelligence; then
    info "Stage 3 already complete: Intelligence control layer."
    return 0
  fi

  say
  say "============================================================"
  say "STAGE 3 — INTELLIGENCE, LM STUDIO, PLASMA AND STARTUP"
  say "============================================================"
  say
  "$INTELLIGENCE" install --install-easy --with-lmstudio --with-codex-plugin
  export PATH="$HOME/.local/bin:$HOME/.claude/bin:$PATH"
  have intelligence || die "Intelligence installed but is not visible on PATH. Open a new terminal and rerun."
  touch "$STATE_DIR/03-intelligence.complete"
}

stage_gui_max() {
  if [[ -f "$STATE_DIR/04-gui-max.complete" ]] && \
     systemctl --user is-enabled intelligence-gui.service >/dev/null 2>&1; then
    info "Stage 4 already complete: GUI MAX."
    return 0
  fi

  say
  say "============================================================"
  say "STAGE 4 — GUI MAX, PLASMA WIDGETS AND DESKTOP BUTTONS"
  say "============================================================"
  say
  "$GUI_MAX" install --no-open
  touch "$STATE_DIR/04-gui-max.complete"
}

stage_authentication() {
  say
  say "============================================================"
  say "STAGE 5 — INTERACTIVE ACCOUNT CONNECTIONS"
  say "============================================================"
  say

  if have codex && [[ ! -f "$STATE_DIR/codex-login.complete" ]]; then
    if codex login status >/dev/null 2>&1; then
      touch "$STATE_DIR/codex-login.complete"
    elif ask_yes "Connect Codex to your ChatGPT/OpenAI account now?"; then
      codex login
      codex login status && touch "$STATE_DIR/codex-login.complete"
    else
      warn "Codex login skipped; local/OpenClaw fallbacks remain available."
    fi
  fi

  if have openclaw && [[ ! -f "$STATE_DIR/openclaw-openai-login.complete" ]]; then
    if ask_yes "Connect OpenClaw's Codex harness to OpenAI now?"; then
      openclaw models auth login --provider openai
      touch "$STATE_DIR/openclaw-openai-login.complete"
    else
      warn "OpenClaw OpenAI login skipped. Run it later from the Intelligence recommendations."
    fi
  fi

  if have gh && [[ ! -f "$STATE_DIR/github-login.complete" ]]; then
    if gh auth status >/dev/null 2>&1; then
      touch "$STATE_DIR/github-login.complete"
    elif ask_yes "Connect GitHub CLI now?"; then
      gh auth login
      gh auth status && touch "$STATE_DIR/github-login.complete"
    else
      warn "GitHub login skipped."
    fi
  fi
}

stage_start_and_test() {
  say
  say "============================================================"
  say "STAGE 6 — START AND VERIFY"
  say "============================================================"
  say

  intelligence sync || true
  openclaw gateway restart || true
  systemctl --user start intelligence-login.service || true
  intelligence models serve || warn "LM Studio is optional and did not start. Ollama remains available."
  intelligence doctor

  if ask_yes "Run one real read-only Intelligence conversation test now?"; then
    intelligence chat \
      "Reply briefly: CHRISTOPHER INTELLIGENCE ONLINE. Then name the active primary route and one useful next task for Anthony. Do not execute anything."
  fi

  touch "$STATE_DIR/05-tested.complete"
}

finish() {
  rm -f -- "$AUTOSTART_FILE"
  say
  say "============================================================"
  say "CHRISTOPHER INTELLIGENCE IS INSTALLED"
  say "============================================================"
  say
  say "Open the Plasma application menu and choose:"
  say "  AI Control Centre"
  say "  OpenClaw Web GUI"
  say
  say "Or run:"
  say "  intelligence control"
  say "  intelligence doctor"
  say "  intelligence chat \"What should we work on now?\""
  say
  say "Setup log: $LOG_FILE"
  say
  if ask_yes "Open the full visual AI Control Centre now?"; then
    exec xdg-open http://127.0.0.1:8765/
  fi
}

main() {
  if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
  fi
  mkdir -p "$STATE_DIR"
  exec > >(tee -a "$LOG_FILE") 2>&1
  preflight
  install_autostart_resume
  stage_workstation
  stage_autopilot
  stage_intelligence
  stage_gui_max
  stage_authentication
  stage_start_and_test
  finish
}

main "$@"
