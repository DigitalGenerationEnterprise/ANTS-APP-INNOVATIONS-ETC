CHRISTOPHER AI-PC — DO THIS NOW
================================

1. Extract the ZIP into your Downloads folder.

2. Open Konsole.

3. Paste these exact commands:

   cd ~/Downloads/CHRISTOPHER-AI-PC-BUNDLE
   chmod +x RUN-ME-FIRST.sh
   ./RUN-ME-FIRST.sh

4. Enter your normal Kubuntu password when sudo asks.

5. The NVIDIA stage may reboot the computer once. After login, setup should
   reopen automatically. If it does not, run the same three commands again.
   Finished stages are detected and skipped.

6. Complete the OpenClaw/Codex/GitHub browser login screens when asked. Never
   paste passwords, cookies or private keys into an AI prompt.

7. When setup finishes, open "AI Control Centre" or "OpenClaw Web GUI" from
   Plasma. The installer also adds live Christopher GPU and AI Services widgets.
   The main visual hub is:

   http://127.0.0.1:8765/

   The official OpenClaw Web GUI is:

   http://127.0.0.1:18789/

   The terminal control menu remains available:

   intelligence control

Useful checks:

   intelligence doctor
   intelligence models status
   intelligence chat "What should we work on now?"

Logs:

   ~/.local/state/christopher-ai-pc-bootstrap/bootstrap.log
   ~/AI-PC/Logs/christopher-install.log

The launcher never creates permanent passwordless root access. Missing optional
tools are reported and skipped, while completed installation stages are retained.
